# Here's a challenge for you to help you practice
# See if you can fix the code below 

# print the message
print('Why won't this line of code print')

# print the message
prnit('This line fails too!')

# print the message
print "I think I know how to fix this one"

# print the name entered by the user
input('Please tell me your name: ')
print(name)
