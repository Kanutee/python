from array import array
scores = array('d')
scores.append(97)
scores.append(98)
print(scores)