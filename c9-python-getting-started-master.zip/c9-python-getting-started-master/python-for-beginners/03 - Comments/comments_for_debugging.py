print('Hello world')
print('It's a small world after all')
