from datetime import datetime

# What if we want different messages displayed?
# Can we still use a function?
first_name = 'Susan'
print('first name assigned')
print(datetime.now())
print() 

for x in range(0,10):
	print(x)
print('loop completed')
print(datetime.now())
print()
