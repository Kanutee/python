# The input funciton allows you to prompt the user for a value
# You need to declare a variable to hold the value entered by the user
name = input('What is your name? ')

print(name)