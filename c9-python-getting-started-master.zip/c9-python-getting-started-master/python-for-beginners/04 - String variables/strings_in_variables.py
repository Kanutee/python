# You can store strings in variables
first_name = 'Susan'

# The variable can then be used later in your code
print(first_name)
