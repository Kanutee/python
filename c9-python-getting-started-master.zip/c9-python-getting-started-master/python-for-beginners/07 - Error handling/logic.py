x = 206
y = 42
if x < y:
    print(str(x) + ' is greater than ' + str(y))
