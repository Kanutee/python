# Comments

Comments start with a hash character (#) and allow you to document your code.
Comments are ignored when code is executed.

- [Comments](https://docs.python.org/3/reference/lexical_analysis.html?highlight=comment)
