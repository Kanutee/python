# print today's date
# print yesterday's date
# ask a user to enter a date
# print the date one week from the date entered