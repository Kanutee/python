def display(message, is_warning=False):
    if is_warning:
        print('Warning!!')
    print(message)
