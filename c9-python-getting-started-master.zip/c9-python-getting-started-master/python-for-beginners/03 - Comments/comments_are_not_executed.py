# This is a comment in my code it does nothing
# print('Hello world')
# print("Hello world")
# No output will be displayed!
