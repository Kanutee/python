# You can use the + operator to concatenate strings
first_name = 'Susan'
last_name = 'Ibach'
print(first_name + last_name)

# If you want a space between the strings you must include the space
# within the string
print('Hello ' + first_name + ' ' + last_name)
