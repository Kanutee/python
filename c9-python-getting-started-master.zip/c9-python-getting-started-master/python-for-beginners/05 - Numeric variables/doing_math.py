# Because the variables are assigned numeric values when created
# Python knows they are numeric variables
first_num = 6
second_num = 2

# You can peform a variety of math operations on numeric values
print('addition')
print(first_num + second_num)
print('subtraction')
print(first_num - second_num)
print('multiplication')
print(first_num * second_num)
print('division')
print(first_num / second_num)
print ('exponent')
print(first_num ** second_num)
