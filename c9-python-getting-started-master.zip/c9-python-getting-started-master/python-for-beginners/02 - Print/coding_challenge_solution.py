# Here's a challenge for you to help you practice
# See if you can fix the code below 

# print the message
# There was a single quote inside the string!
# Use double quotes to enclose the string
print("Why won't this line of code print")

# print the message
# There was a mistake in the function name
print('This line fails too!')

# print the message
# Need to add the () around the string
print ("I think I know how to fix this one")

# print the name entered by the user
# You need to store the value returned by the input statement
# in a variable
name = input('Please tell me your name: ')
print(name)
