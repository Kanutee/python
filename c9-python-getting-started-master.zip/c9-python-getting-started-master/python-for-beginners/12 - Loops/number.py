# range creates an array
# First parameter is the starter
# Second indicates the number of numbers to create
# range(0, 2) creates [0, 1]
for index in range(0, 2):
	print(index)
