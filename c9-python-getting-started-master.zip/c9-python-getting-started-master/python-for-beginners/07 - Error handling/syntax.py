x = 42
y = 206
if x == y
    print('Success')