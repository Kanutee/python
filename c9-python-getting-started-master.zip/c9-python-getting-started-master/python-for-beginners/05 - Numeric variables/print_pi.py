# You can use variables to store numeric values
pi = 3.14159
print(pi)
