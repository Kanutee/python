x = 12
if x == 24:
 print('Is valid')
else:
    print("Not valid")

def helper(name='sample'):
 pass

def another(name = 'sample'):
         pass
