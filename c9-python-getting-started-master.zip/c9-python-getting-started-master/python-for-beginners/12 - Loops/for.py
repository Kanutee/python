for name in ['Christopher', 'Susan']:
	print(name)
