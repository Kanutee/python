
province = input("What province do you live in? ")
tax = 0

if province == 'Alberta': 
	tax = 0.05
if province == 'Nunavut':
	tax = 0.05
if province == 'Ontario':
	tax = 0.13
print(tax)
