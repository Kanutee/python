first_num = input('Enter first number ')
second_num = input('Enter second number ')
# If you have a string variable containing a number
# And you want to treat it as a number
# You must convert it to a numeric datatype
# int() converts a string to an integer e.g. 5, 8, 416, 506
print(int(first_num) + int(second_num))

# float() converts a string to a decimal or float number e.g. 3.14159, 89.5, 1.0
print(float(first_num) + float(second_num))

