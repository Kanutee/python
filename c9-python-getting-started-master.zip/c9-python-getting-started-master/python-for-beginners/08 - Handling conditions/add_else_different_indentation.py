price = 5.0
if price >= 1.00:
	tax = .07
else:
	tax = 0
# the print statement below is not indented so is executed after the if 
# statement is evaluated
print(tax)
