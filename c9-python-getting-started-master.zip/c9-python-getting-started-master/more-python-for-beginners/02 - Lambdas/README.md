# Lambdas

A [lambda](https://www.w3schools.com/python/python_lambda.asp) function is a small anonymous function. It can take any number of arguments but can only execute one expression.

## Microsoft Learn Resources

Explore related tutorials on [Microsoft Learn](https://learn.microsoft.com/?WT.mc_id=python-c9-niner).

- [Create reusable functionality with functions in Python](https://docs.microsoft.com/learn/languages/python-functions/?WT.mc_id=python-c9-niner)
