# Classes

[Classes](https://docs.python.org/3/tutorial/classes.html) define data structures and behavior. Classes allow you to group data and functionality together.

## Microsoft Learn Resources

Explore related tutorials on [Microsoft Learn](https://learn.microsoft.com/?WT.mc_id=python-c9-niner).

- [Object-oriented programming in Python](https://docs.microsoft.com/learn/modules/python-object-oriented-programming/?WT.mc_id=python-c9-niner)
