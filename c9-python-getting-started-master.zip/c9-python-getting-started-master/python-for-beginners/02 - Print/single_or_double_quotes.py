# Strings can be enclosed in single quotes
print('Hello world single quotes')

# Strings can also be enclosed in double quotes
print("Hello world double quotes")
