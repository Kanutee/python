# the print statement displays a message 
print('Hello world')
