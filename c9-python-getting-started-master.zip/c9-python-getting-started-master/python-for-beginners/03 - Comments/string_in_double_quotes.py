# Using double quotes for this string because 
# the string itself contains a single quote
print("It's a small world after all")
